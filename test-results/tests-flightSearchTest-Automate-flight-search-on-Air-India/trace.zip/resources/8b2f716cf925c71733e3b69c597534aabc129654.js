const OptanonWrapper = () => {
    const activeCatgories = OnetrustActiveGroups ? OnetrustActiveGroups : [];
    checkForCookieBlock(activeCatgories);
}

const checkForCookieBlock = (categories) => {
    // block performance cookies
    if (!categories.includes('C0002')) {
        const cookieList = ['utm_campaign', 'utm_medium', 'utm_source', 'ADRUM'];
        blockCookie(cookieList);
    }

    // block targeting cookies
    if (!categories.includes('C0004')) {
        const cookieList = ['_fbp'];
        blockCookie(cookieList);
    }
}

const blockCookie = (cookieList) => {
    cookieList.forEach((cookieName => {
        document.cookie = cookieName + '=; domain=.airindia.com; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    }));
}

window.addEventListener('load', () => {
    OptanonWrapper();
});

window.addEventListener('OneTrustGroupsUpdated', (event) => {
    const activeCategories = event?.detail ? event?.detail : [];
    checkForCookieBlock(activeCategories);
});